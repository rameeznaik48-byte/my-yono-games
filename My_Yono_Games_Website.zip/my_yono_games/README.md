# My Yono Games

A mobile-friendly app directory inspired by the supplied screenshot, with a password-protected admin panel.

## Requirements
- Node.js 18 or newer
- npm

## Run locally
1. Extract this ZIP.
2. Open a terminal in this folder.
3. Install dependencies: `npm install`
4. Set an admin password:
   - macOS/Linux: `ADMIN_PASSWORD='choose-a-strong-password' npm start`
   - Windows PowerShell: `$env:ADMIN_PASSWORD='choose-a-strong-password'; npm start`
5. Open `http://localhost:3000`.
6. Admin panel: `http://localhost:3000/admin`.

## Admin features
- Add, edit and delete app listings
- Choose All Games or New Apps category
- Set rating, subtitle, HOT badge and icon
- Add an official app page URL

The data is stored in `games.json`. Back up this file regularly.

## Before publishing
- Deploy on a Node.js hosting provider that supports persistent storage.
- Set `ADMIN_PASSWORD` as a private environment variable; never put it in frontend code.
- Use HTTPS and configure backups.
- Replace the sample listings with apps you have independently verified.
- Only link to official publisher download pages. Do not claim a bonus, rating, player count or verification unless you can substantiate it.
- This starter is an app directory only. It does not process payments, deposits, bets or withdrawals. Check applicable laws and platform policies before listing any real-money gaming service.
- For production use, add rate limiting, CSRF protection, secure admin sessions, audit logs and database-backed storage.
