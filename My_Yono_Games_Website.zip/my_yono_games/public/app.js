let allGames = [], activeTab = "games";
const cards = document.getElementById("cards");
const search = document.getElementById("search");
document.getElementById("year").textContent = new Date().getFullYear();
function escapeHTML(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function safeUrl(value){try{const u=new URL(value);return ["https:","http:"].includes(u.protocol)?u.href:"";}catch{return "";}}
function render(){
 const q=search.value.trim().toLowerCase();
 const list=allGames.filter(g=>g.category===activeTab && (g.name+" "+g.description).toLowerCase().includes(q));
 document.getElementById("count").textContent=list.length+" apps";
 if(!list.length){cards.innerHTML='<div class="empty">No apps found. Try another search.</div>';return;}
 cards.innerHTML=list.map(g=>{
  const url=safeUrl(g.downloadUrl), icon=safeUrl(g.icon);
  return `<article class="game-card">${g.hot?'<span class="hot">🔥 HOT</span>':""}
   <div class="game-icon">${icon?`<img src="${escapeHTML(icon)}" alt="">`:escapeHTML(g.icon||"🎮")}</div>
   <div class="game-info"><h3>${escapeHTML(g.name)}</h3><div class="meta">${escapeHTML(g.players)} · ⭐ ${Number(g.rating||0).toFixed(1)}</div><div class="bonus">${escapeHTML(g.bonus||"Details not provided")}</div></div>
   ${url?`<a class="download" href="${escapeHTML(url)}" target="_blank" rel="noopener noreferrer">Visit App ↗</a>`:`<span class="download disabled">Not available</span>`}
  </article>`;
 }).join("");
}
async function load(){try{const r=await fetch("/api/games");allGames=await r.json();render();}catch{cards.innerHTML='<div class="empty">Could not load apps. Please refresh.</div>';}}
search.addEventListener("input",render);
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{activeTab=b.dataset.tab;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));render();}));
load();