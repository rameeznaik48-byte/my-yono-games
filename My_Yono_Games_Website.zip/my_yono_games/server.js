const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD) {
  console.error("Set ADMIN_PASSWORD before starting the server.");
  process.exit(1);
}
const DATA_FILE = path.join(__dirname, "games.json");
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function readGames() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function writeGames(games) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(games, null, 2));
}
function safeGame(g) {
  return {
    id: String(g.id || crypto.randomUUID()),
    name: String(g.name || "").trim().slice(0, 80),
    players: String(g.players || "New app").slice(0, 40),
    rating: Math.max(0, Math.min(5, Number(g.rating) || 0)),
    bonus: String(g.bonus || "").slice(0, 60),
    category: g.category === "new" ? "new" : "games",
    hot: Boolean(g.hot),
    icon: String(g.icon || "🎮").slice(0, 500),
    downloadUrl: String(g.downloadUrl || "").slice(0, 1000),
    description: String(g.description || "").slice(0, 300)
  };
}
function adminOnly(req, res, next) {
  const token = req.headers["x-admin-password"];
  if (token !== ADMIN_PASSWORD) return res.status(401).json({ error: "Incorrect admin password." });
  next();
}
app.get("/api/games", (req, res) => res.json(readGames()));
app.post("/api/admin/login", (req, res) => {
  if (!req.body || req.body.password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Incorrect password." });
  res.json({ ok: true });
});
app.post("/api/games", adminOnly, (req, res) => {
  const game = safeGame(req.body || {});
  if (!game.name) return res.status(400).json({ error: "Game name is required." });
  const games = readGames();
  games.unshift(game); writeGames(games); res.status(201).json(game);
});
app.put("/api/games/:id", adminOnly, (req, res) => {
  const games = readGames();
  const index = games.findIndex(g => g.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: "Game not found." });
  const updated = safeGame({ ...req.body, id: req.params.id });
  if (!updated.name) return res.status(400).json({ error: "Game name is required." });
  games[index] = updated; writeGames(games); res.json(updated);
});
app.delete("/api/games/:id", adminOnly, (req, res) => {
  const games = readGames().filter(g => g.id !== req.params.id);
  writeGames(games); res.json({ ok: true });
});
app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.listen(PORT, () => console.log(`My Yono Games running at http://localhost:${PORT}`));