# My Yono Games

A responsive static game-discovery website for GitHub Pages.

## Publish on GitHub Pages
1. Upload `index.html`, `style.css`, and `script.js` to the root of your repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main` and folder `/(root)`, then save.
5. Wait for GitHub Pages to finish deploying.

This is a static front-end demo. It does not process payments, deposits, or bets.
