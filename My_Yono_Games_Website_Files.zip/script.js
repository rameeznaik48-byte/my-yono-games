const games = [
  {name:"Neon Runner",category:"Arcade",icon:"🏃",description:"Dodge obstacles and chase your best score."},
  {name:"Mind Match",category:"Puzzle",icon:"🧩",description:"Match pairs and give your memory a workout."},
  {name:"Space Defender",category:"Action",icon:"🚀",description:"Protect your galaxy in this action-style game."},
  {name:"Block Builder",category:"Puzzle",icon:"🧱",description:"Fit shapes together and solve each board."},
  {name:"Turbo Drift",category:"Arcade",icon:"🏎️",description:"Take on turns and improve your racing line."},
  {name:"Shadow Quest",category:"Action",icon:"⚔️",description:"Explore a fantasy world and take on challenges."}
];
const grid=document.getElementById("gameGrid");
const search=document.getElementById("searchInput");
const count=document.getElementById("gameCount");
const empty=document.getElementById("emptyState");
let category="All";
function render(){
  const term=search.value.trim().toLowerCase();
  const shown=games.filter(g=>(category==="All"||g.category===category)&&(g.name.toLowerCase().includes(term)||g.description.toLowerCase().includes(term)));
  grid.innerHTML=shown.map(g=>`<article class="game-card"><div class="game-icon">${g.icon}</div><h3>${g.name}</h3><p>${g.description}</p><span class="tag">${g.category}</span></article>`).join("");
  count.textContent=`${shown.length} ${shown.length===1?"game":"games"}`;
  empty.classList.toggle("hidden",shown.length!==0);
}
document.getElementById("filters").addEventListener("click",e=>{
  const btn=e.target.closest("button[data-category]");if(!btn)return;
  category=btn.dataset.category;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===btn));
  render();
});
search.addEventListener("input",render);
document.getElementById("year").textContent=new Date().getFullYear();
render();