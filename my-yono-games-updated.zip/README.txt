MY YONO GAMES — UPDATED FILES

Files:
- index.html: public website
- admin.html: admin panel

Upload/replace both files in the root of your existing GitHub Pages repository.
Keep the filenames exactly index.html and admin.html.

Admin URL:
https://rameeznaik48-byte.github.io/my-yono-games/admin.html

Important Supabase requirements:
1. Your Supabase project must already contain a `games` table with these columns:
   id, name, category, description, game_url, apk_url, image_url, published, created_at.
2. Create a Storage bucket named `game-images` and make it public so website visitors can see uploaded game images.
3. Configure Supabase Auth > URL Configuration so the GitHub Pages site URL and its admin.html redirect URL are allowed.
4. Configure Row Level Security policies so only the authenticated admin account can insert/update/delete games, while public visitors can read published games. The publishable key is intended for browser use; never put a service-role key in these files.

The code keeps the existing Supabase project and admin email supplied in the original admin.html.
If your existing database/bucket policies are already configured, you should not need to recreate them.
